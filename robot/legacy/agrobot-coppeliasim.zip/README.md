# AgroBot — protótipo para CoppeliaSim

Protótipo demonstrativo de um robô móvel que monitora e irriga quatro áreas de cultivo. Cada área possui uma cultura, um valor de umidade simulado e um limite de acionamento configurável.

O pacote cria automaticamente a cena no CoppeliaSim e disponibiliza um painel web em `http://127.0.0.1:8000`.

## Funcionalidades

- quatro setores: alface, tomate, pimentão e morango;
- um sensor lógico de umidade por setor;
- deslocamento automático do robô até o setor mais seco;
- representação visual do jato de água;
- horários permitidos de funcionamento;
- limites de umidade e duração da irrigação independentes por cultura;
- irrigação manual e pausa do modo automático;
- histórico recente de eventos;
- geração de uma cena `AgroBotPrototype.ttt` no computador onde for executado.

> A umidade e o jato de água são abstrações de software. O protótipo não simula hidráulica nem o comportamento físico real do solo.

## Requisitos

- CoppeliaSim Edu 4.8 ou mais recente;
- Python 3.10 ou mais recente;
- navegador moderno.

## Como executar

1. Abra o CoppeliaSim e selecione **File > New scene**.
2. Deixe o CoppeliaSim aberto.
3. Abra um terminal nesta pasta.
4. Crie e ative um ambiente virtual:

```bash
python -m venv .venv
```

No Windows:

```powershell
.venv\Scripts\activate
```

No Linux/macOS:

```bash
source .venv/bin/activate
```

5. Instale as dependências e inicie o protótipo:

```bash
pip install -r requirements.txt
python agrobot.py
```

6. Acesse `http://127.0.0.1:8000`.

O arquivo `AgroBotPrototype.ttt` será salvo na pasta atual. O controle continua sendo realizado pelo programa Python; por isso, abrir somente o `.ttt` não inicia a automação.

## Opções úteis

```bash
python agrobot.py --help
python agrobot.py --web-port 8080
python agrobot.py --no-save-scene
python agrobot.py --coppelia-host 192.168.0.10
```

## Demonstração sugerida

1. Abra o painel e mostre as quatro culturas.
2. Diminua manualmente a umidade de um setor.
3. Eleve o limite desse setor e salve.
4. Observe o robô deslocar-se e irrigá-lo.
5. Pause o modo automático e acione outro setor manualmente.
6. Mostre o histórico registrando todas as decisões.

## Caminho para o protótipo físico

Na versão real, substitua os valores simulados por sensores capacitivos instalados nos setores. Um ESP32 pode publicar as leituras para a plataforma, enquanto motores com encoders controlam o deslocamento e um relé ou MOSFET aciona a bomba. Antes de utilizar em uma produção, calibre os sensores em cada tipo de solo e implemente fins de curso, parada de emergência, detecção de reservatório vazio e limite máximo de bombeamento.

